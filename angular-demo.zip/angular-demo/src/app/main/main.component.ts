import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {
/*main slider js start*/
  public slideConfig = {
    autoplay:true,
    autoplaySpeed:7000,
    speed:600,
    slidesToShow:1,
    slidesToScroll:1,
    pauseOnHover:false,
    dots:true,
    pauseOnDotsHover:true,
    cssEase:'linear',
    fade:true,
    draggable:false,
    prevArrow:'<button class="PrevArrow"> <span class="Thumbnail"></span></button>',
    nextArrow:'<button class="NextArrow"> <span class="Thumbnail"></span></button>', 
    responsive: [
      {
        breakpoint: 991,
        settings: {
          arrows:false,   
        }
      },         
    ]       
  };
/*main slider js end*/

/*counter bellow slider js start*/
  public imgboxslider ={
    autoplay:true,
     autoplaySpeed:2000,
     speed:600,
     slidesToShow:4,
     slidesToScroll:1,
     pauseOnHover:false,     
     pauseOnDotsHover:true,      
     draggable:false,
     arrows:false,
     responsive: [
      {
        breakpoint: 991,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,          
          dots: true,   
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          dots: true, 
        }
      }    
    ]    
  };

  /*counter bellow  slider js end*/

 /*testnomial slider js start*/ 
  
  carouselOptions = {
    margin:50,
    nav: true,
    navText: ["<div class='nav-btn prev-slide'></div>", "<div class='nav-btn next-slide'></div>"],
    responsiveClass: true,    
    responsive: {
      0: {
        items: 1,
        nav: true
      },
      600: {
        items: 1,
        nav: true
      },
      991: {
        items: 1,
        nav: true,
        loop: false,
        dots:true,
      },
      1000: {
        items: 2,
        nav: true,
        loop: false,
        dots:true,
      },
      1500: {      
        items: 2, 
        nav: true,
        loop: false
      }
    }
  }

  /*testnomial slider js end*/


  /*client logo slider js start*/

  public clientlogo ={
    autoplay:true,
    autoplaySpeed:2000,
    speed:600,
    slidesToShow:5,
    slidesToScroll:1,
    pauseOnHover:false,     
    pauseOnDotsHover:true,      
    draggable:false,
    arrows:false,
    responsive: [
     {
       breakpoint: 991,
       settings: {
         slidesToShow: 3,
         slidesToScroll: 1,          
         dots: true,   
       }
     },
     {
       breakpoint: 600,
       settings: {
         slidesToShow: 1,
         slidesToScroll: 1,
         dots: true, 
       }
     }    
   ]
  };
  /*client logo slider js end*/

  constructor() { }

  ngOnInit() {

  }

}

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MainComponent } from './main/main.component';
import { TestComponent } from './test/test.component';
import { ProductComponent } from './product/product.component';
import { ContactComponent } from './contact/contact.component';
import { HeaderComponent } from './header/header.component';

const  routes: Routes = [
{ path:  '', redirectTo:  '/main', pathMatch:  'full' },
{ path:  'main', component:  MainComponent },
{ path: 'test', component: TestComponent },
{ path: 'product', component: ProductComponent },
{ path: 'contact', component: ContactComponent },
{ path: 'header', component: HeaderComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})

export class AppRoutingModule { }

